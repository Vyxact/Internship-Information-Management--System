<?php
session_start();

require_once("db.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Internship Info</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="css/AdminLTE.min.css">
    <link rel="stylesheet" href="css/_all-skins.min.css">
    <!-- Custom -->
    <link rel="stylesheet" href="css/custom.css">

    <!-- Google Font -->
    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-green sidebar-mini">


<div class="wrapper">

<header class="main-header">

<!-- Logo -->
<a href="index.php" class="logo">
    <!-- logo for regular state and mobile devices -->
    <span class="logo-lg"><b>Internship Information Management System</b></span>
</a>

<!-- Header Navbar: style can be found in header.less -->
<nav class="navbar navbar-static-top">
    <!-- Navbar Right Menu -->
    <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
            <li>
                <a href="internships.php"><b>Internships</b></a>
            </li>
            
            <?php if (empty($_SESSION['id_student']) && empty($_SESSION['id_company'])) { ?>
                <li>
                    <a href="login.php"><b>Login</b></a>
                </li>
                <li>
                    <a href="sign-up.php"><b>Sign Up</b></a>
                </li>
            <?php } else {

                if (isset($_SESSION['id_student'])) {
                    ?>
                    <li>
                        <a href="user/index.php"><b>Dashboard</b></a>
                    </li>
                    <?php
                } else if (isset($_SESSION['id_company'])) {
                    ?>
                    <li>
                        <a href="company/index.php"><b>Dashboard</b></a>
                    </li>
                <?php } ?>
                <li>
                    <a href="logout.php"><b>Logout</b></a>
                </li>
            <?php } ?>
        </ul>
    </div>
</nav>
</header>


   <!--<section id="about" class="content-header">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center latest-job margin-bottom-20">
                            <h1>Welcome</h1>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 about-text margin-bottom-20">
                            <h3>Internship Platform for Foreign Students</h3>
                            <p align="justify">The online Internship info application allows internship seekers and recruiters to connect. The
                                application provides the ability for internship seekers to create their accounts, upload their
                                profile and resume or cv, search for internships, apply for internships, view different internship openings. The
                                application provides the ability for companies to create their accounts, search candidates,
                                create internship postings, and view candidates applications.
                            </p>
                            <p align="justify">
                                This website is used to provide a platform for potential candidates to get their dream internship
                                and excel in their career.
                                This site can be used as a paving path for both companies and internship-seekers for a better life.
                            </p>
                        </div>
                        <div class="col-md-6">
                            <img src="img/aboutus.png" class="img-responsive">
                        </div>
                    </div>
                </div>
            </section>-->

    
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper" style="margin-left: 0px;">

       
        <section id="about" class="content-header">
            <div class="container">
                


                <div class="row">
                    
                    <div class="col-md-6 about-text margin-bottom-20">
                        <h2> <strong>Millions of Internship Available to Foreign Students in China</strong></h2>
                        
                        <p><a class="btn btn-success btn-lg" href="internships.php" role="button"><big>Find Internship Programs</big></a></p>
                    
                    </div>
                    <div class="col-md-6">
                        <img src="img/indeximg1.svg" class="img-responsive">
                    </div>

                </div>
            </div>
        </section>

        <section id="about" class="content-header">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center latest-job margin-bottom-20">
                        

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <img src="img/indeximg2.svg" class="img-responsive">
                    </div>
                    <div class="col-md-6 about-text margin-bottom-20">
                        <h3>Are you are a company?</h3>
                        <p align="justify">Find all your talent in one place
                        Never place a Internship ad again. 
                        Unlock the future of hiring new talent through 
                        our platform ready-to-deploy talents and squads 
                        for the internship of today and tomorrow.
                        </p>
                        <h3>Are you are a Student?</h3>
                        <p align="justify">Become an Intern and gain experience from 
                            top verified companies.Discover your perfect career through
                             our free website , fast-track your learning and become 
                             an Intern through our world-leading partners </p>
                        
                        <p><a class="btn btn-success btn-lg" href="sign-up.php" role="button"><big>Start Now</big></a></p>
                    
                    </div>
                    

                </div>
            </div>
        </section>

        <section class="content-header">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 latest-internship margin-bottom-20">
                        <h2 class="text-center">Featured  Internships</h2>
                        <?php
                        $sql = "SELECT * FROM internship_post Order By Rand() Limit 4";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $sql1 = "SELECT * FROM company WHERE id_company='$row[id_company]'";
                                $result1 = $conn->query($sql1);
                                if ($result1->num_rows > 0) {
                                    while ($row1 = $result1->fetch_assoc()) {
                                        ?>
                                        <div class="attachment-block clearfix">
                                            <img class="attachment-img" src="img/internship_index_post.jpg" alt="Attachment Image">
                                            <div class="attachment-pushed">
                                                <h4 class="attachment-heading"><a
                                                            href="view-internship-post.php?id=<?php echo $row['id_internshippost']; ?>"><?php echo $row['internshiptitle']; ?></a>
                                                    <span class="attachment-heading pull-right"><?php echo $row['maximumsalary']; ?>rmb
                                                        monthly</span></h4>
                                                <div class="attachment-text">
                                                    <div><strong><?php echo $row1['companyname']; ?>
                                                            | <?php echo $row1['city']; ?> |
                                                            Years of Study <?php echo $row['knowledgeexperience']; ?> Years</strong>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                }
                            }
                        }
                        ?>

                    </div>
                </div>
            </div>
        </section>

        

        <section id="about" class="content-header">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center latest-job margin-bottom-20">
                        <h2>Statistics</h2>
                    </div>
                </div>
                <div class="row">
                            <div class="col-md-6">
                                <!--<div class="info-box bg-c-yellow">-->
                                <div class="info-box bg-c">
                                    <span class="info-box-icon bg-green"><i class="ion ion-person-stalker"></i></span>
                                    <div class="info-box-content">
                                        <span class="info-box-text"><b>Active Registered Interns</b></span>
                                        <?php
                                        $sql = "SELECT * FROM students WHERE active='1'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            $totalno = $result->num_rows;
                                        } else {
                                            $totalno = 0;
                                        }
                                        ?>
                                        <span class="info-box-number"><?php echo $totalno; ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                            <div class="info-box bg-c">
                                    <span class="info-box-icon bg-green"><i class="ion ion-briefcase"></i></span>
                                    <div class="info-box-content">
                                        <span class="info-box-text"><b>Active Registered Companies</b></span>
                                        <?php
                                        $sql = "SELECT * FROM company WHERE active='1'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            $totalno = $result->num_rows;
                                        } else {
                                            $totalno = 0;
                                        }
                                        ?>
                                        <span class="info-box-number"><?php echo $totalno; ?></span>
                                    </div>
                                </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-box bg-c">
                                    <span class="info-box-icon bg-green"><i class="ion ion-person-add"></i></span>
                                    <div class="info-box-content">
                                        <span class="info-box-text"><b>Total Internship Posts</b></span>
                                        <?php
                                        $sql = "SELECT * FROM internship_post";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            $totalno = $result->num_rows;
                                        } else {
                                            $totalno = 0;
                                        }
                                        ?>
                                        <span class="info-box-number"><?php echo $totalno; ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-box bg-c">
                                    <span class="info-box-icon bg-green"><i class="ion ion-ios-browsers"></i></span>
                                    <div class="info-box-content">
                                        <span class="info-box-text"><b>Total Applications</b></span>
                                        <?php
                                        $sql = "SELECT * FROM apply_internship_post";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            $totalno = $result->num_rows;
                                        } else {
                                            $totalno = 0;
                                        }
                                        ?>
                                        <span class="info-box-number"><?php echo $totalno; ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                <div class="row">
                    
                    <div class="col-md-6 about-text margin-bottom-20">
                        <h3></h3>
                        <p></p>
                        <p align="justify"></p>
                    </div>
                    <div class="col-md-6">
                        <!--<img src="img/aboutus.png" class="img-responsive">-->
                    </div>
                    
                </div>
            </div>
        </section>

    </div>
    <!-- /.content-wrapper -->

    <footer class="main-footer" style="margin-left: 0px;">
        <div class="text-center">
        <strong>&copy; Internship Information Management System</strong>
        </div>
    </footer>

    <div class="control-sidebar-bg"></div>

</div>

<!-- jQuery 3 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="js/adminlte.min.js"></script>
</body>
</html>
