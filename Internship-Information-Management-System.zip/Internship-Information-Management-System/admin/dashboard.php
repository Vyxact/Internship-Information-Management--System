<?php

session_start();

if (empty($_SESSION['id_admin'])) {
    header("Location: index.php");
    exit();
}

require_once("../db.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Internship Info</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../css/AdminLTE.min.css">
    <link rel="stylesheet" href="../css/_all-skins.min.css">
    <!-- Custom -->
    <link rel="stylesheet" href="../css/custom.css">

    <!-- Google Font -->
    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-green sidebar-mini">
<div class="wrapper">

    <header class="main-header">

        <!-- Logo -->
        <a href="../index.php" class="logo">
            <!-- mini logo for sidebar mini 50x50 pixels -->
            <span class="logo-mini"><b>II</b>MS</span>
            <!-- logo for regular state and mobile devices -->
            <span class="logo-lg"><b>Internship Information Management System</b></span>
        </a>

        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top">
            <!-- Navbar Right Menu -->
            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">

                </ul>
            </div>
        </nav>
    </header>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper" style="margin-left: 0px;">

        <section id="candidates" class="content-header">
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                        <div class="box box-solid">
                            <div class="box-header with-border">
                                <h3 class="box-title">Welcome</h3>
                                <h3 class="box-title"><b>Admin</b></h3>
                            </div>
                            <div class="box-body no-padding">
                                <ul class="nav nav-pills nav-stacked">
                                    <li class="active"><a href="dashboard.php"><i class="fa fa-dashboard"></i><b> Dashboard</b></a>
                                    </li>
                                    <li><a href="active-internships.php"><i class="fa fa-briefcase"></i><b> Active Internships</b></a></li>
                                    <li><a href="applications.php"><i class="fa fa-address-card-o"></i><b> Applications</b></a>
                                    </li>
                                    <li><a href="companies.php"><i class="fa fa-building"></i><b> Companies</b></a></li>
                                    <li><a href="../logout.php"><i class="fa fa-arrow-circle-o-right"></i><b> Logout</b></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9 bg-white padding-2">

                        <center><h3><b>Internship Information Management Statistics</b></h3></center></br>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="info-box">
                                    <span class="info-box-icon"><i class="ion ion-briefcase"></i></span>
                                    <div class="info-box-content">
                                        <span class="info-box-text"><b>Active Registered Companies</b></span>
                                        <?php
                                        $sql = "SELECT * FROM company WHERE active='1'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            $totalno = $result->num_rows;
                                        } else {
                                            $totalno = 0;
                                        }
                                        ?>
                                        <span class="info-box-number"><?php echo $totalno; ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-box">
                                    <span class="info-box-icon"><i class="ion ion-briefcase"></i></span>
                                    <div class="info-box-content">
                                        <span class="info-box-text"><b>Pending Company Approval</b></span>
                                        <?php
                                        $sql = "SELECT * FROM company WHERE active='2'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            $totalno = $result->num_rows;
                                        } else {
                                            $totalno = 0;
                                        }
                                        ?>
                                        <span class="info-box-number"><?php echo $totalno; ?></span>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-box">
                                    <span class="info-box-icon"><i class="ion ion-person-stalker"></i></span>
                                    <div class="info-box-content">
                                        <span class="info-box-text"><b>Active Registered Interns</b></span>
                                        <?php
                                        $sql = "SELECT * FROM students WHERE active='1'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            $totalno = $result->num_rows;
                                        } else {
                                            $totalno = 0;
                                        }
                                        ?>
                                        <span class="info-box-number"><?php echo $totalno; ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-box">
                                    <span class="info-box-icon"><i class="ion ion-person-stalker"></i></span>
                                    <div class="info-box-content">
                                        <span class="info-box-text"><b>Pending Intern Confirmation</b></span>
                                        <?php
                                        $sql = "SELECT * FROM students WHERE active='0'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            $totalno = $result->num_rows;
                                        } else {
                                            $totalno = 0;
                                        }
                                        ?>
                                        <span class="info-box-number"><?php echo $totalno; ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-box">
                                    <span class="info-box-icon"><i class="ion ion-person-add"></i></span>
                                    <div class="info-box-content">
                                        <span class="info-box-text"><b>Total Internship Posts</b></span>
                                        <?php
                                        $sql = "SELECT * FROM internship_post";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            $totalno = $result->num_rows;
                                        } else {
                                            $totalno = 0;
                                        }
                                        ?>
                                        <span class="info-box-number"><?php echo $totalno; ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-box">
                                    <span class="info-box-icon"><i class="ion ion-ios-browsers"></i></span>
                                    <div class="info-box-content">
                                        <span class="info-box-text"><b>Total Applications</b></span>
                                        <?php
                                        $sql = "SELECT * FROM apply_internship_post";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            $totalno = $result->num_rows;
                                        } else {
                                            $totalno = 0;
                                        }
                                        ?>
                                        <span class="info-box-number"><?php echo $totalno; ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>


    </div>
    <!-- /.content-wrapper -->

    <footer class="main-footer" style="margin-left: 0px;">
        <div class="text-center">
        <strong>&copy; Internship Information Management System</strong>
        </div>
    </footer>

    <!-- /.control-sidebar -->
    <!-- Add the sidebar's background. This div must be placed
         immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="../js/adminlte.min.js"></script>
</body>
</html>
