<?php

//To Handle Session Variables on This Page
session_start();

if(empty($_SESSION['id_student'])) {
	header("Location: index.php");
	exit();
}

//Including Database Connection From db.php file to avoid rewriting in all files
require_once("db.php");

//If user Actually clicked apply button
if(isset($_GET)) {

	$sql = "SELECT * FROM internship_post WHERE id_internshippost='$_GET[id]'";
	  $result = $conn->query($sql);
	  if($result->num_rows > 0) 
	  {
	    	$row = $result->fetch_assoc();
	    	$id_company = $row['id_company'];
	   }

	//Check if user has applied to internship post or not. If not then add his details to apply_internship_post table.
	$sql1 = "SELECT * FROM apply_internship_post WHERE id_student='$_SESSION[id_student]' AND id_internshippost='$row[id_internshippost]'";
    $result1 = $conn->query($sql1);
    if($result1->num_rows == 0) {  
    	
    	$sql = "INSERT INTO apply_internship_post(id_internshippost, id_company, id_student) VALUES ('$_GET[id]', '$id_company', '$_SESSION[id_student]')";

		if($conn->query($sql)===TRUE) {
			$_SESSION['internshipApplySuccess'] = true;
			header("Location: user/index.php");
			exit();
		} else {
			echo "Error " . $sql . "<br>" . $conn->error;
		}

		$conn->close();

    }  else {
		header("Location: internships.php");
		exit();
	}
	

} else {
	header("Location: internships.php");
	exit();
}