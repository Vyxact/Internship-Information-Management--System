				Project Title: Internship Information Management System

SQL FILE LOCATION:
			Internship-Information-Management-System/Internship_IMS.sql

/*! 
* ================
* @license MIT <http://opensource.org/licenses/MIT>
* I used Free admin dashboard template based on Bootstrap 4 in AdminLTE app.js
*/

USERS:


	1. SYSTEM ADMIN
		URL LINK - http://localhost/Internship-Information-Management-System/admin/index.php 
			USERNAME: admin
			PASSWORD: 123456
	
	
	2. COMPANY
		URL LINK - http://localhost/Internship-Information-Management-System/login-company.php  
			EMAIL: recruit@transsion.com
			PASSWORD: 123456
			
			
	3. STUDENT
		URL LINK - http://localhost/Internship-Information-Management-System/login-interns.php
			EMAIL: lydiajohnson@gmail.com
			PASSWORD: 123456
			